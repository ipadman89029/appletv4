# -*- coding: utf-8 -*-
import os, sys, re, uuid, urllib, urllib2, net
from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcaddon, xbmcplugin, xbmc_url
from xbmcswift2.ext.playlist import playlist
from xbmcaddon import Addon
from os import path as os_path
from json import loads

# Plugin initialization
PLUGIN_NAME = 'Simple PVR'
PLUGIN_ID = 'plugin.video.simplepvr'
source_url = 'http://liveapp.fpiptv.com'

plugin = Plugin(PLUGIN_NAME, PLUGIN_ID, __file__)
mac = ':'.join(re.findall('..', '%012x' % uuid.getnode()));
net = net.Net()

# Common function
def open_url(url):

    try:
        req = urllib2.Request(url)
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except Exception as e:
        link ='website down'

    return link

# Get live stream url compatible with Kodi from VLC playlist
def resolve_url(url):
    stream_url = url
    try:
	url = url.decode('utf-8')
	headers  = {
	    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
	    "Connection":"keep-alive",
	    "Accept-Encoding":"gzip, deflate, sdch",
	    "Host":"http://fpiptv.com",
	    "Accept-Language":"en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4",
	    "Upgrade-Insecure-Requests":"1",
	    "User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36"
	}
	stream_url = net.http_GET(url, headers).get_url()
	return stream_url
    except:
	stream_url = None

    return stream_url

class track:

    def __init__(self, title, path, thumb, desc):

	self.title = title
	self.path = path
	self.thumb = thumb
	self.desc = desc

# Get the playlist from m3u file
def get_playlist():

    playlist = []
    channel = track(None, None, None, None)
    data = open_url(source_url)
    content = data.rstrip()
    match = re.compile(r'#EXTINF:-1,(.+?),(.*?)[\n\r]+([^\n]+)').findall(content)

    for other, channel_name, stream_url in match:
        channel.title = channel_name
        channel.path  = stream_url
        channel.desc  = ''
        
        thumb = ''
        logo_url = 'http://logos.fpiptvsupport.com/'
        if 'tvg-logo' in other:
            thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
            if thumbnail:
                thumb = logo_url + thumbnail
        else:
            thumb = ''
            
        channel.thumb = thumb
        
        playlist.append(channel)
        channel = track(None, None, None, None)

    return playlist

    
def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match
    
# Get MAC address
def get_mac():

    global mac;

    return mac;

# Get public IP
def get_ip():

    entry = open_url("http://httpbin.org/ip")
    data = loads(entry)

    return data['origin']

# Root view
@plugin.route('/')
def index():

    items = []
    items.append({
	'label': '[B][COLOR silver]Configure you[/COLOR][COLOR red] PVR Simple Client[/COLOR][/B]',
	'path': plugin.url_for('do_configure'),
	'thumbnail': 'http://img.haozhaopian.net/share/1464156582351uhU.jpg',
	'info': {'plot': '', },
	'is_playable': False,
    })

    items.append({
	'label': '',
	'path': plugin.url_for('show_ip'),
	'thumbnail': 'http://img.haozhaopian.net/share/1464156582351uhU.jpg',
	'is_playable': False,
    })

    items.append({
	'label': '',
	'path': plugin.url_for('show_mac'),
	'thumbnail': 'http://img.haozhaopian.net/share/1464156582351uhU.jpg',
	'info': {'plot': '', },
	'is_playable': False,
    })

    return plugin.finish(items)

@plugin.route('/ip/')
def show_ip():

    items = []
    items.append({
        'label': '[COLOR red]%s[/COLOR]' %(get_ip()),
        'thumbnail': 'http://img.haozhaopian.net/share/1464156582351uhU.jpg',
        'info': {'plot': '', },
        'is_playable': False,
    })

    return plugin.finish(items)

@plugin.route('/mac/')
def show_mac():

    items = []
    items.append({
	'label': '[COLOR red]%s[/COLOR]' %(get_mac()),
	'thumbnail': 'http://img.haozhaopian.net/share/1464156582351uhU.jpg',
	'info': {'plot': '', },
	'is_playable': False,
    })

    return plugin.finish(items)

@plugin.route('/configure/')
def do_configure():

    file_path_settings = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'userdata', 'addon_data', 'pvr.iptvsimple', 'settings.xml')
    folder_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'userdata', 'addon_data', 'pvr.iptvsimple')
    
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        
    file = open(file_path_settings, 'w')
    file.write('<settings>\n')
    file.write('<setting id="epgCache" value="false" />\n')
    file.write('<setting id="epgPath" value="" />\n')
    file.write('<setting id="epgPathType" value="1" />\n')
    file.write('<setting id="epgTSOverride" value="true" />\n')
    file.write('<setting id="epgTimeShift" value="-5.000000" />\n')
    file.write('<setting id="epgUrl" value="http://epg.fpiptv.com" />\n')
    file.write('<setting id="logoBaseUrl" value="http://logos.fpiptvsupport.com" />\n')
    file.write('<setting id="logoFromEpg" value="0" />\n')
    file.write('<setting id="logoPath" value="" />\n')
    file.write('<setting id="logoPathType" value="1" />\n')
    file.write('<setting id="m3uCache" value="false" />\n')
    file.write('<setting id="m3uPath" value="" />\n')
    file.write('<setting id="m3uPathType" value="1" />\n')
    file.write('<setting id="m3uUrl" value="http://live.fpiptv.com" />\n')
    file.write('<setting id="sep1" value="" />\n')
    file.write('<setting id="sep2" value="" />\n')
    file.write('<setting id="sep3" value="" />\n')
    file.write('<setting id="startNum" value="1" />\n')
    file.write('</settings>\n')
    file.close()

    dialog = xbmcgui.Dialog()
    dialog.ok('[COLOR silver]Configuration[/COLOR] of [COLOR red]PVR[/COLOR] is [COLOR silver]Successful[/COLOR]', '[COLOR red]The PVR Simple Client of you KODI has been successfully configured.[/COLOR][COLOR silver]Please restart Kodi for the changes to take effect.[/COLOR]')
    
    # items = []
    # items.append({
	# 'label': '[COLOR red]%s[/COLOR]' %('Comming Soon!'),
	# 'thumbnail': '',
	# 'info': {'plot': '', },
	# 'is_playable': False,
    # })

    # return plugin.finish(items)
    
    return None

@plugin.route('/livetv/')
def build_livetv():

    tds = []
    items = []
    tds = get_playlist()

    if tds is not None:
        for td in tds:            
            items.append({
	        'label': td.title,
	        'path': plugin.url_for('play_resolved_url', name=td.title, thumbnail=td.thumb, url=td.path),
	        'thumbnail': td.thumb,
	        'is_playable': False,
	    })

    return plugin.finish(items)

@plugin.route('/play/<name>/<thumbnail>/<url>/')
def play_resolved_url(name, thumbnail, url):
    url = resolve_url(url)
    if url is not None:
        try:
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
            listitem.setInfo(type='Video', infoLabels={'Title': name})
            xbmc.Player().play(url, listitem)
            
        except:
            traceback.print_exc()
        return None
        
    else:
        exit(0)

if __name__ == '__main__':
    plugin.run()